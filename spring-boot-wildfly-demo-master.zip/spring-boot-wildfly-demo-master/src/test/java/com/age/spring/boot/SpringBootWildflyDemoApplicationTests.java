package com.age.spring.boot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootWildflyDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
